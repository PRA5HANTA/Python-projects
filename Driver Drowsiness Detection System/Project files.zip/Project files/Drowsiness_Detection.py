from scipy.spatial import distance
from dotenv import load_dotenv
from imutils import face_utils
from pygame import mixer
import numpy as np
import imutils
import dlib
import cv2
import time
import os
from twilio.rest import Client
import requests 

# Initialize mixer for alarm sound
mixer.init()
mixer.music.load("music.wav")
load_dotenv()

# Define Twilio API for phone calls
def make_call():
    account_sid = os.getenv('TWILIO_ACCOUNT_SID')  # Replace with your Twilio account SID
    auth_token = os.getenv('TWILIO_AUTH_TOKEN')    # Replace with your Twilio auth token
    client = Client(account_sid, auth_token)

    try:
        call = client.calls.create(
            twiml='<Response><Say>Warning, the driver is drowsy. Please respond.</Say></Response>',
            to='+916290765983',  # Replace with the recipient's phone number
            from_='+12095002196'  # Replace with your Twilio phone number
        )
        print(f"Call initiated with SID: {call.sid}")
    except Exception as e:
        print(f"Error making call: {e}")



# Route prediction settings
MAX_DRIVE_TIME = 2 * 60 * 60  # Max driving time before break (2 hours)
DROWSINESS_ALERT_THRESHOLD = 3
drive_start_time = time.time()
drowsiness_alert_count = 0

# Check driving duration and alert for breaks
def check_drive_duration():
    current_time = time.time()
    elapsed_time = current_time - drive_start_time
    if elapsed_time > MAX_DRIVE_TIME:
        print("Alert: You have been driving for over 2 hours. Please take a break.")
        return True
    return False

# Optional function to find nearby rest areas
def find_nearby_rest_areas(lat,lng):
   url = "https://nominatim.openstreetmap.org/search"
   params = {
       "q": "rest area",
       "format": "json",
       "limit": 5,
       "addressdetails": 1,
       "lat": lat,
       "lon": lng
   }
   try:
       response = requests.get(url, params=params)
       response.raise_for_status()
       print("JSON response:",response.json())
       locations = response.json()

       

       if not locations:
           print("No nearby rest areas found.")
           return 
       
       for i, location in enumerate(locations, start=1):
           print(f"Location {i}:")
           print("Name:", location.get("display_name"))
           print("Latitude:", location.get("lat"))
           print("Longitude:", location.get("lon"))
           print("-" * 30)
           return locations
   except requests.RequestException as e:
       print(f"Error occurred: {e}")
       return None
       

# Eye aspect ratio calculation
def eye_aspect_ratio(eye):
    A = distance.euclidean(eye[1], eye[5])
    B = distance.euclidean(eye[2], eye[4])
    C = distance.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear
# Thresholds and counters
thresh = 0.25
frame_check = 20
detect = dlib.get_frontal_face_detector()
predict = dlib.shape_predictor("models/shape_predictor_68_face_landmarks.dat")

(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_68_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_68_IDXS["right_eye"]
cap = cv2.VideoCapture(0)
flag = 0
alarm_start_time = None
notification_sent = False

# Manual call test: Uncomment the next line to test Twilio call manually
# make_call()

while True:
    ret, frame = cap.read()
    frame = imutils.resize(frame, width=450)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    subjects = detect(gray, 0)

    for subject in subjects:
        shape = predict(gray, subject)
        shape = face_utils.shape_to_np(shape)
        leftEye = shape[lStart:lEnd]
        rightEye = shape[rStart:rEnd]
        leftEAR = eye_aspect_ratio(leftEye)
        rightEAR = eye_aspect_ratio(rightEye)
        ear = (leftEAR + rightEAR) / 2.0
        leftEyeHull = cv2.convexHull(leftEye)
        rightEyeHull = cv2.convexHull(rightEye)
        cv2.drawContours(frame, [leftEyeHull], -1, (0, 255, 0), 1)
        cv2.drawContours(frame, [rightEyeHull], -1, (0, 255, 0), 1)

        if ear < thresh:
            flag += 1
            print(f"EAR below threshold: {ear}, flag: {flag}")
            if flag >= frame_check:
                cv2.putText(frame, "****************ALERT!****************", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                cv2.putText(frame, "****************ALERT!****************", (10, 325),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                
                # Play alarm sound
                if not mixer.music.get_busy():
                    mixer.music.play()
                    if not alarm_start_time:
                        alarm_start_time = time.time()  # Start the timer when alarm begins
                        print(f"Alarm started at {alarm_start_time}")

                # Check if alarm has been playing for 15+ seconds
                if alarm_start_time:
                    elapsed_time = time.time() - alarm_start_time
                    print(f"Alarm active for {elapsed_time} seconds")
                    
                    if elapsed_time > 15 and not notification_sent:
                        print("15 seconds passed, initiating call...")
                        make_call()
                        notification_sent = True

        else:
            flag = 0
            alarm_start_time = None
            notification_sent = False


    # Route check every hour (mock current location)
    if int(time.time() - drive_start_time) % 300 == 0:
        print("Checking route and rest areas...")
        find_nearby_rest_areas(37.7749, -122.4194)

     # Check if driving duration exceeds limit
    if check_drive_duration():
        print("You have been driving for a long time. Break suggested.")

        
    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break

cv2.destroyAllWindows()
cap.release()
